create database PromiKlausur;
create table Spenden(
	id int not null auto_increment primary key, 
	Spender varchar(30) not null
	Betrag int not null
	
);
