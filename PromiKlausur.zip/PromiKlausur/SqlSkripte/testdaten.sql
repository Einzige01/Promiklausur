insert into Spenden(id, Spender, Betrag) values
(1,'Lucy',250),
(2,'Ella',140),
(3,'Amy',50),
(4,'Lukas',200),
(5,'Ben',210),
(6,'Jonal',270);
